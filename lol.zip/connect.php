<?php 
$connect = mysqli_connect('localhost', 'id18114313_mixrussiayakutia', 'aPruo?d1{\p?Pj$s', 'id18114313_mixrussia');
 ?>